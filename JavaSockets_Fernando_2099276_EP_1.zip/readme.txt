Para executar o código é necessário ter o maven instalado

Depois de ter instalado o maven, executar o servidor normalmente com java

javac Servidor.java na pasta src/main/java/projeto

para executar o Cliente, rodar na pasta raiz do projeto "JavaSockets", o comando mvn javafx:run