package projeto.requests.filmes;

public class ListFilmePayload {
    public final String operacao = "LISTAR_FILMES".toUpperCase();

    public ListFilmePayload() {
    }
}
